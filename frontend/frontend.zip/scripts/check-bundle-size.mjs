import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

const DIST_DIR = path.join(process.cwd(), "dist");
const MANIFEST_PATH = path.join(DIST_DIR, ".vite", "manifest.json");

const BUDGETS = {
  entryChunkGzip: 350 * 1024,      // 350KB
  syncTreeGzip: 500 * 1024,       // 500KB
};

function getGzipSize(filePath) {
  try {
    const content = fs.readFileSync(filePath);
    return zlib.gzipSync(content).length;
  } catch (err) {
    console.error(`❌ Failed to read or gzip file ${filePath}:`, err.message);
    return 0;
  }
}

function main() {
  console.log("📊 Checking bundle size budgets...\n");

  if (!fs.existsSync(MANIFEST_PATH)) {
    console.error(`❌ Manifest not found at: ${MANIFEST_PATH}`);
    console.error("   Run `npm run build` first.");
    process.exit(1);
  }

  const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, "utf-8"));

  // Find the entry chunk
  let entryKey = null;
  let entryChunk = null;

  for (const [key, value] of Object.entries(manifest)) {
    if (value.isEntry) {
      entryKey = key;
      entryChunk = value;
      break;
    }
  }

  if (!entryChunk) {
    console.error("❌ Could not find entry chunk in manifest.");
    process.exit(1);
  }

  console.log(`🔑 Entry Key: ${entryKey}`);
  console.log(`📦 Entry Chunk File: ${entryChunk.file}`);

  const entryFilePath = path.join(DIST_DIR, entryChunk.file);
  const entryGzipSize = getGzipSize(entryFilePath);
  const entryGzipSizeKB = (entryGzipSize / 1024).toFixed(2);
  const entryBudgetKB = (BUDGETS.entryChunkGzip / 1024).toFixed(0);

  console.log(`   - Main Entry Chunk size (Gzip): ${entryGzipSizeKB} KB (Budget: ${entryBudgetKB} KB)`);

  // Recursively collect all synchronous imports
  const visited = new Set();
  const queue = [entryKey];

  while (queue.length > 0) {
    const currentKey = queue.shift();
    if (visited.has(currentKey)) continue;
    visited.add(currentKey);

    const chunk = manifest[currentKey];
    if (chunk && chunk.imports) {
      for (const importKey of chunk.imports) {
        if (!visited.has(importKey)) {
          queue.push(importKey);
        }
      }
    }
  }

  console.log(`\n🌳 Synchronous dependency tree contains ${visited.size} chunks:`);
  let totalSyncGzipSize = 0;
  let hasOverBudget = false;

  for (const chunkKey of visited) {
    const chunk = manifest[chunkKey];
    if (!chunk) continue;
    const chunkFilePath = path.join(DIST_DIR, chunk.file);
    const chunkGzipSize = getGzipSize(chunkFilePath);
    totalSyncGzipSize += chunkGzipSize;
    console.log(`   - ${chunk.file}: ${(chunkGzipSize / 1024).toFixed(2)} KB`);
  }

  const totalSyncGzipSizeKB = (totalSyncGzipSize / 1024).toFixed(2);
  const syncBudgetKB = (BUDGETS.syncTreeGzip / 1024).toFixed(0);
  console.log(`\n📦 Total Sync Tree size (Gzip): ${totalSyncGzipSizeKB} KB (Budget: ${syncBudgetKB} KB)`);

  if (entryGzipSize > BUDGETS.entryChunkGzip) {
    console.error(`❌ Main entry chunk exceeds budget of ${entryBudgetKB} KB!`);
    hasOverBudget = true;
  }

  if (totalSyncGzipSize > BUDGETS.syncTreeGzip) {
    console.error(`❌ Synchronous dependency tree exceeds budget of ${syncBudgetKB} KB!`);
    hasOverBudget = true;
  }

  if (hasOverBudget) {
    console.error("\n❌ Bundle budget validation FAILED.");
    process.exit(1);
  } else {
    console.log("\n✅ Bundle budget validation PASSED.");
    process.exit(0);
  }
}

main();
