import { apiRequest } from "./client";
import { TaskDtoSchema, TaskListDtoSchema, TaskModel } from "../schemas/tasks";
import { mapTaskDto } from "../mappers/tasks";
import { z } from "zod";

export async function getTask(taskId: string, signal?: AbortSignal): Promise<TaskModel> {
  const dto = await apiRequest(`/tasks/${taskId}`, {
    method: "GET",
    schema: TaskDtoSchema,
    signal,
  });
  return mapTaskDto(dto);
}

export async function cancelTask(taskId: string): Promise<void> {
  await apiRequest(`/tasks/${taskId}/cancel`, {
    method: "POST",
    schema: z.unknown(),
  });
}

export async function getTasksList(): Promise<TaskModel[]> {
  const dtos = await apiRequest("/tasks", {
    method: "GET",
    schema: TaskListDtoSchema,
  });
  return dtos.map(mapTaskDto);
}