import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "../../api/queryKeys";
import { getTask } from "../../api/tasks";
import { TaskStatus } from "../../schemas/tasks";
import {
  taskStreamTransport,
  TaskEventDto,
  TaskStreamConnection,
} from "../../api/taskStreamTransport";
import { z } from "zod";

// DTO result validators
const PathGenerationResultSchema = z.object({
  path_id: z.string(),
  version: z.number().int().positive().optional(),
});

const UnitGenerationResultSchema = z.object({
  path_id: z.string(),
  node_id: z.string(),
  unit_id: z.string().optional(),
});

// Terminal states
const TERMINAL_STATUSES = new Set([
  "completed",
  "partial_completed",
  "failed",
  "cancelled",
  "expired",
  "interrupted",
]);

export interface TaskSubscriber {
  onMessage: (event: TaskEventDto) => void;
  onError: (err: Error) => void;
}

interface SharedTaskConnection {
  taskId: string;
  subscribers: Set<TaskSubscriber>;
  transportConnection: TaskStreamConnection | null;
  state: "connecting" | "connected" | "reconnecting" | "polling" | "terminal";
  latestEvent: TaskEventDto | null;
  seenEventIds: Set<string>;
  reconnectAttempts: number;
  connectionEpoch: number;
  reconnectTimerId: ReturnType<typeof setTimeout> | null;
  pollTimerId: ReturnType<typeof setTimeout> | null;
  terminalCleanupTimerId: ReturnType<typeof setTimeout> | null;
  terminalAt: number | null;
}

const taskConnections = new Map<string, SharedTaskConnection>();
const CLEANUP_DELAY_MS = 5_000;
const STALE_SWEEP_INTERVAL_MS = 30_000;
const TERMINAL_CACHE_DURATION_MS = 30_000;
const MAX_SEEN_EVENTS = 500;

let sweepIntervalId: ReturnType<typeof setInterval> | null = null;

function ensureRegistrySweep() {
  if (sweepIntervalId !== null) return;
  sweepIntervalId = setInterval(sweepExpiredConnections, STALE_SWEEP_INTERVAL_MS);
}

function sweepExpiredConnections() {
  const now = Date.now();
  for (const [taskId, shared] of taskConnections.entries()) {
    if (shared.subscribers.size === 0) {
      const isTerminalCacheExpired =
        shared.state === "terminal" &&
        shared.terminalAt !== null &&
        now - shared.terminalAt >= TERMINAL_CACHE_DURATION_MS;

      const isNonTerminalStale = shared.state !== "terminal";

      if (isTerminalCacheExpired || isNonTerminalStale) {
        closeSharedConnection(shared);
        taskConnections.delete(taskId);
      }
    }
  }
  if (taskConnections.size === 0 && sweepIntervalId !== null) {
    clearInterval(sweepIntervalId);
    sweepIntervalId = null;
  }
}

function closeSharedConnection(shared: SharedTaskConnection) {
  if (shared.transportConnection) {
    shared.transportConnection.close();
    shared.transportConnection = null;
  }
  if (shared.reconnectTimerId !== null) {
    clearTimeout(shared.reconnectTimerId);
    shared.reconnectTimerId = null;
  }
  if (shared.pollTimerId !== null) {
    clearTimeout(shared.pollTimerId);
    shared.pollTimerId = null;
  }
  if (shared.terminalCleanupTimerId !== null) {
    clearTimeout(shared.terminalCleanupTimerId);
    shared.terminalCleanupTimerId = null;
  }
}

export function disposeTaskConnectionRegistry() {
  for (const shared of taskConnections.values()) {
    closeSharedConnection(shared);
  }
  taskConnections.clear();
  if (sweepIntervalId !== null) {
    clearInterval(sweepIntervalId);
    sweepIntervalId = null;
  }
}

function startPhysicalConnection(shared: SharedTaskConnection) {
  if (shared.state === "terminal") return;
  shared.connectionEpoch += 1;
  const currentEpoch = shared.connectionEpoch;

  shared.state = "connecting";
  if (shared.transportConnection) {
    shared.transportConnection.close();
    shared.transportConnection = null;
  }

  const isHookManaged = taskStreamTransport.recoveryMode === "hook-managed";

  try {
    shared.transportConnection = taskStreamTransport.connect(shared.taskId, {
      onMessage: (event) => {
        if (shared.connectionEpoch !== currentEpoch) return;

        if (shared.seenEventIds.has(event.event_id)) return;
        shared.seenEventIds.add(event.event_id);
        if (shared.seenEventIds.size > MAX_SEEN_EVENTS) {
          const firstKey = shared.seenEventIds.values().next().value;
          if (firstKey !== undefined) {
            shared.seenEventIds.delete(firstKey);
          }
        }

        shared.latestEvent = event;
        shared.reconnectAttempts = 0;
        shared.state = "connected";

        shared.subscribers.forEach((sub) => sub.onMessage(event));

        if (TERMINAL_STATUSES.has(event.status)) {
          handleTerminalStateTransition(shared, event);
        }
      },
      onError: (err) => {
        if (shared.connectionEpoch !== currentEpoch) return;
        if (shared.state === "terminal") return;
        shared.lastError = err;
        notifyConnectionState(shared);
        if (isHookManaged) {
          restartPhysicalConnection(shared);
        } else {
          shared.subscribers.forEach((sub) => sub.onError(err));
        }
      },
    });
  } catch (err: any) {
    shared.lastError = err instanceof Error ? err : new Error(String(err));
    notifyConnectionState(shared);
    if (isHookManaged) {
      restartPhysicalConnection(shared);
    } else {
      shared.subscribers.forEach((sub) => sub.onError(err));
    }
  }
}

function restartPhysicalConnection(shared: SharedTaskConnection) {
  if (shared.state === "terminal") return;
  if (shared.reconnectTimerId !== null) {
    clearTimeout(shared.reconnectTimerId);
    shared.reconnectTimerId = null;
  }
  if (shared.transportConnection) {
    shared.transportConnection.close();
    shared.transportConnection = null;
  }
  shared.state = "reconnecting";

  const delays = [1000, 2000, 4000, 8000, 15000];
  const attempt = shared.reconnectAttempts;

  if (attempt >= 5) {
    startFallbackPolling(shared);
  } else {
    shared.reconnectAttempts++;
    shared.reconnectTimerId = setTimeout(() => {
      startPhysicalConnection(shared);
    }, delays[attempt]);
  }
}

function startFallbackPolling(shared: SharedTaskConnection) {
  shared.state = "polling";

  const poll = async () => {
    if (shared.state !== "polling") return;
    try {
      const isVisible = typeof document !== "undefined" ? document.visibilityState === "visible" : true;
      if (!isVisible) {
        shared.pollTimerId = setTimeout(poll, 10000);
        return;
      }

      const task = await getTask(shared.taskId);
      const event: TaskEventDto = {
        event_id: `poll-${task.taskId}-${task.status}-${task.progress}-${task.updatedAt}`,
        task_id: task.taskId,
        type: task.status === "completed" ? "completed" : (task.status === "failed" ? "failed" : "progress"),
        status: task.status,
        progress: task.progress,
        stage: task.currentStage,
        message: task.message,
        result: task.result,
        timestamp: new Date().toISOString(),
      };

      shared.latestEvent = event;
      shared.subscribers.forEach((sub) => sub.onMessage(event));

      if (TERMINAL_STATUSES.has(task.status)) {
        handleTerminalStateTransition(shared, event);
      } else {
        shared.pollTimerId = setTimeout(poll, 3000);
      }
    } catch (err: any) {
      shared.subscribers.forEach((sub) => sub.onError(err));
      if (shared.state === "polling") {
        shared.pollTimerId = setTimeout(poll, 3000);
      }
    }
  };

  poll();
}

function handleTerminalStateTransition(shared: SharedTaskConnection, event: TaskEventDto) {
  closeSharedConnection(shared);
  shared.state = "terminal";
  shared.latestEvent = event;
  shared.terminalAt = Date.now();

  shared.terminalCleanupTimerId = setTimeout(() => {
    if (shared.subscribers.size === 0) {
      taskConnections.delete(shared.taskId);
    }
  }, TERMINAL_CACHE_DURATION_MS);
}

export function subscribeToTask(taskId: string, subscriber: TaskSubscriber): () => void {
  ensureRegistrySweep();
  let shared = taskConnections.get(taskId);

  if (shared) {
    if (shared.terminalCleanupTimerId !== null) {
      clearTimeout(shared.terminalCleanupTimerId);
      shared.terminalCleanupTimerId = null;
    }
  } else {
    shared = {
      taskId,
      subscribers: new Set(),
      transportConnection: null,
      state: "connecting",
      latestEvent: null,
      seenEventIds: new Set(),
      reconnectAttempts: 0,
      connectionEpoch: 0,
      reconnectTimerId: null,
      pollTimerId: null,
      terminalCleanupTimerId: null,
      terminalAt: null,
    };
    taskConnections.set(taskId, shared);
    startPhysicalConnection(shared);
  }

  shared.subscribers.add(subscriber);

  if (shared.latestEvent) {
    subscriber.onMessage(shared.latestEvent);
  }

  return () => {
    const active = taskConnections.get(taskId);
    if (!active) return;
    active.subscribers.delete(subscriber);

    if (active.subscribers.size === 0) {
      if (active.state === "terminal") {
        if (active.terminalCleanupTimerId === null) {
          const timeSinceTerminal = active.terminalAt ? Date.now() - active.terminalAt : 0;
          const remainingTime = Math.max(0, TERMINAL_CACHE_DURATION_MS - timeSinceTerminal);
          active.terminalCleanupTimerId = setTimeout(() => {
            if (active.subscribers.size === 0) {
              taskConnections.delete(taskId);
            }
          }, remainingTime);
        }
      } else {
        active.terminalCleanupTimerId = setTimeout(() => {
          if (active.subscribers.size === 0) {
            closeSharedConnection(active);
            taskConnections.delete(taskId);
          }
        }, CLEANUP_DELAY_MS);
      }
    }
  };
}

export function useTaskStream(taskId: string | null | undefined) {
  const queryClient = useQueryClient();
  const [progress, setProgress] = useState<number>(0);
  const [message, setMessage] = useState<string>("正在连接任务流...");
  const [stage, setStage] = useState<string | null>(null);
  const [status, setStatus] = useState<TaskStatus>("pending");
  const [error, setError] = useState<string | null>(null);
  const [pathId, setPathId] = useState<string | null>(null);

  useEffect(() => {
    if (!taskId) return;

    setProgress(0);
    setMessage("正在初始化任务...");
    setStage(null);
    setStatus("pending");
    setError(null);
    setPathId(null);

    const handleMessage = (event: TaskEventDto) => {
      setProgress(event.progress);
      setMessage(event.message || "");
      setStage(event.stage);
      setStatus(event.status);

      if (event.status === "failed") {
        setError((event.result?.error as string) || event.message || "任务执行失败");
      }

      if (TERMINAL_STATUSES.has(event.status)) {
        queryClient.invalidateQueries({ queryKey: queryKeys.tasks() });
        if (event.status === "completed" && event.result) {
          const pathParse = PathGenerationResultSchema.safeParse(event.result);
          if (pathParse.success) {
            setPathId(pathParse.data.path_id);
            queryClient.invalidateQueries({ queryKey: queryKeys.path(pathParse.data.path_id) });
          }
          const unitParse = UnitGenerationResultSchema.safeParse(event.result);
          if (unitParse.success) {
            queryClient.invalidateQueries({
              queryKey: queryKeys.unit(unitParse.data.path_id, unitParse.data.node_id),
            });
          }
        }
      }
    };

    const handleError = () => {};

    const unsubscribe = subscribeToTask(taskId, {
      onMessage: handleMessage,
      onError: handleError,
    });

    return () => {
      unsubscribe();
    };
  }, [taskId, queryClient]);

  const registryConnection = taskConnections.get(taskId || "");
  const currentIsPolling = registryConnection?.state === "polling";

  return {
    progress,
    message,
    stage,
    status,
    error,
    pathId,
    isPolling: currentIsPolling,
  };
}
