import { z } from "zod";

export const TaskStatusSchema = z.enum([
  "pending",
  "running",
  "cancel_requested",
  "completed",
  "partial_completed",
  "failed",
  "cancelled",
  "expired",
  "interrupted",
]);

export type TaskStatus = z.infer<typeof TaskStatusSchema>;

export const TaskTypeSchema = z.enum([
  "learning_goal_analysis",
  "learning_diagnostic_generation",
  "learning_path_generation",
  "learning_path_revision",
  "learning_unit_generation",
  "learning_assessment_generation",
  "learning_path_adaptation",
  "knowledge_index",
  "knowledge_reindex",
]);

export type TaskType = z.infer<typeof TaskTypeSchema>;

export const TaskDtoSchema = z.object({
  task_id: z.string(),
  type: TaskTypeSchema,
  title: z.string(),
  status: TaskStatusSchema,
  progress: z.number().min(0).max(100),
  current_stage: z.string().nullable(),
  message: z.string().nullable(),
  result: z.record(z.string(), z.unknown()).nullable(),
  error: z.string().nullable(),
  request_id: z.string().nullable(),
  created_at: z.string().datetime({ offset: true }),
  updated_at: z.string().datetime({ offset: true }),
});

export type TaskDto = z.infer<typeof TaskDtoSchema>;


export const TaskListDtoSchema = z.array(TaskDtoSchema);
export type TaskListDto = z.infer<typeof TaskListDtoSchema>;

export const ApiErrorDtoSchema = z.object({
  message: z.string(),
  code: z.string().optional(),
  details: z.unknown().optional(),
});
export type ApiErrorDto = z.infer<typeof ApiErrorDtoSchema>;

export interface TaskModel {
  taskId: string;
  type: TaskType;
  title: string;
  status: TaskStatus;
  progress: number;
  currentStage: string | null;
  message: string | null;
  result: Record<string, unknown> | null;
  error: string | null;
  requestId: string | null;
  createdAt: string;
  updatedAt: string;
}
