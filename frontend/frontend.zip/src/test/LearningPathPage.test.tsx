import React from "react";
import { describe, it, expect, beforeEach } from "vitest";
import { screen } from "@testing-library/react";
import { Route, Routes } from "react-router-dom";
import { LearningPathPage } from "../pages/LearningPathPage";
import { useWorkspaceStore } from "../stores/workspace";
import { renderWithProviders } from "./renderWithProviders";

describe("LearningPathPage Component", () => {
  beforeEach(() => {
    useWorkspaceStore.getState().resetWorkspace();
  });

  it("should render 404 page for non-existent learning path IDs", async () => {
    renderWithProviders(
      <Routes>
        <Route path="/learning-paths/:pathId" element={<LearningPathPage />} />
      </Routes>,
      { route: "/learning-paths/invalid-path" }
    );

    expect(await screen.findByText(/404 - 页面未找到/)).toBeInTheDocument();
  });

  it("should render 3-column workspace elements for valid path ID", async () => {
    window.innerWidth = 1280;
    window.dispatchEvent(new Event("resize"));

    renderWithProviders(
      <Routes>
        <Route path="/learning-paths/:pathId" element={<LearningPathPage />} />
      </Routes>,
      { route: "/learning-paths/mock-path" }
    );

    // Verify Progress Header
    expect((await screen.findAllByText("数据结构与图算法通关路径")).length).toBeGreaterThan(0);

    // Verify Left Recommendation panel
    expect(screen.getByText("个性化学习建议")).toBeInTheDocument();

    // Verify Details drawer header exists (it's initialized with current node "tree-traversal")
    expect(screen.getByText("节点详情")).toBeInTheDocument();
    expect(screen.getByText("二叉树的非递归遍历")).toBeInTheDocument();
  });

  it("should sync node selections between store and URL search parameters", async () => {
    window.innerWidth = 1280;
    window.dispatchEvent(new Event("resize"));

    renderWithProviders(
      <Routes>
        <Route
          path="/learning-paths/:pathId"
          element={
            <>
              <LearningPathPage />
              <div data-testid="search-display">
                {window.location.search}
              </div>
            </>
          }
        />
      </Routes>,
      { route: "/learning-paths/mock-path?node=ds-intro" }
    );

    // Initially selected node should follow the ?node URL query parameter (ds-intro)
    expect(await screen.findByText("数据结构基础知识")).toBeInTheDocument();
    expect(useWorkspaceStore.getState().selectedNodeId).toBe("ds-intro");
  });
});
