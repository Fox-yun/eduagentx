import React from "react";
import { describe, it, expect, vi } from "vitest";
import { screen, fireEvent } from "@testing-library/react";
import { ResumePage } from "../pages/ResumePage";
import { renderWithProviders } from "./renderWithProviders";
import { http, HttpResponse } from "msw";

// Mock useNavigate from react-router-dom
const mockNavigate = vi.fn();
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

const mockResumeDto = {
  type: "active",
  path_id: "mock-path",
  path_title: "数据结构与图算法通关路径",
  current_node_id: "tree-traversal",
  current_node_title: "二叉树的非递归遍历",
  completed_nodes: 3,
  total_nodes: 12,
  progress: 25,
  last_active_at: "2026-06-23T03:00:00Z",
};

const resumeHandlers = [
  http.get("/api/learning/resume", () => {
    return HttpResponse.json(mockResumeDto);
  }),
  http.get("http://localhost/api/learning/resume", () => {
    return HttpResponse.json(mockResumeDto);
  }),
  http.get("http://localhost:3000/api/learning/resume", () => {
    return HttpResponse.json(mockResumeDto);
  }),
];

describe("ResumePage Component", () => {
  it("should render student path dashboard and illustration", async () => {
    renderWithProviders(<ResumePage />, {
      handlers: resumeHandlers,
    });

    // Welcome titles
    expect(await screen.findByText("从哪里继续学习？")).toBeInTheDocument();
    expect(screen.getAllByText("继续学习").length).toBeGreaterThan(0);

    // Course title
    expect(screen.getByText("数据结构与图算法通关路径")).toBeInTheDocument();

    // Progress text
    expect(screen.getByText(/已完成 3\/12 节点/)).toBeInTheDocument();
  });

  it("should trigger navigation when continue learning button is clicked", async () => {
    renderWithProviders(<ResumePage />, {
      handlers: resumeHandlers,
    });

    const continueBtn = await screen.findByRole("button", { name: "继续学习" });
    expect(continueBtn).toBeInTheDocument();

    fireEvent.click(continueBtn);
    expect(mockNavigate).toHaveBeenCalledWith("/learning-paths/mock-path?node=tree-traversal");
  });

  it("should trigger navigation when view path button is clicked", async () => {
    renderWithProviders(<ResumePage />, {
      handlers: resumeHandlers,
    });

    const viewPathBtn = await screen.findByRole("button", { name: "查看完整路径" });
    expect(viewPathBtn).toBeInTheDocument();

    fireEvent.click(viewPathBtn);
    expect(mockNavigate).toHaveBeenCalledWith("/learning-paths/mock-path");
  });
});
