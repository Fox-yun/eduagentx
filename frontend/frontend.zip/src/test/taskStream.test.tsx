import { renderHook, act } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useTaskStream, subscribeToTask, disposeTaskConnectionRegistry } from "../features/tasks/useTaskStream";
import { MockTaskStreamTransport, TaskEventDto, setTaskStreamTransport } from "../api/taskStreamTransport";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import React from "react";

// Mock tasks fetch API call to support polling test
vi.mock("../api/tasks", () => {
  return {
    getTask: vi.fn().mockResolvedValue({
      task_id: "test-task-123",
      type: "learning_path_generation",
      title: "Test Task",
      status: "completed",
      progress: 100,
      currentStage: "完成",
      message: "轮询成功",
      result: { path_id: "path-123" },
      error: null,
      requestId: null,
      createdAt: "",
      updatedAt: "",
    }),
  };
});

describe("useTaskStream React Hook & Registry", () => {
  let queryClient: QueryClient;
  const fakeTransport = new MockTaskStreamTransport();

  beforeEach(() => {
    setTaskStreamTransport(fakeTransport);
    queryClient = new QueryClient({
      defaultOptions: {
        queries: { retry: false, gcTime: 0, staleTime: 0 },
      },
    });
    vi.clearAllMocks();
  });

  afterEach(() => {
    disposeTaskConnectionRegistry();
  });

  const wrapper = ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  );

  it("should connect, parse events, and update state from transport stream", async () => {
    const taskId = "task-test-ok";
    const events: TaskEventDto[] = [
      {
        event_id: "evt-1",
        task_id: taskId,
        type: "snapshot",
        status: "pending",
        progress: 0,
        stage: "初始化",
        message: "任务流就绪",
        result: null,
        timestamp: new Date().toISOString(),
      },
      {
        event_id: "evt-2",
        task_id: taskId,
        type: "progress",
        status: "running",
        progress: 50,
        stage: "处理中",
        message: "已生成大纲",
        result: null,
        timestamp: new Date().toISOString(),
      },
    ];

    MockTaskStreamTransport.setMockEvents(taskId, events);

    const { result } = renderHook(() => useTaskStream(taskId), { wrapper });

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 150));
    });

    expect(result.current.progress).toBe(50);
    expect(result.current.message).toBe("已生成大纲");
    expect(result.current.stage).toBe("处理中");
    expect(result.current.status).toBe("running");
  });

  it("should deduplicate events based on event_id", async () => {
    const taskId = "task-test-dedup";
    const events: TaskEventDto[] = [
      {
        event_id: "duplicate-id",
        task_id: taskId,
        type: "progress",
        status: "running",
        progress: 30,
        stage: "分析中",
        message: "第一次发送",
        result: null,
        timestamp: new Date().toISOString(),
      },
      {
        event_id: "duplicate-id",
        task_id: taskId,
        type: "progress",
        status: "running",
        progress: 80,
        stage: "分析中",
        message: "重复发送的相同ID事件，不应该更新此消息",
        result: null,
        timestamp: new Date().toISOString(),
      },
    ];

    MockTaskStreamTransport.setMockEvents(taskId, events);

    const { result } = renderHook(() => useTaskStream(taskId), { wrapper });

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 200));
    });

    expect(result.current.progress).toBe(30);
    expect(result.current.message).toBe("第一次发送");
  });

  it("should cache final snapshots on terminal statuses and close physical connection", async () => {
    const taskId = "task-test-terminal";
    const events: TaskEventDto[] = [
      {
        event_id: "evt-term-1",
        task_id: taskId,
        type: "completed",
        status: "completed",
        progress: 100,
        stage: "完成",
        message: "路径生成完成！",
        result: { path_id: "path-term-999" },
        timestamp: new Date().toISOString(),
      },
    ];

    MockTaskStreamTransport.setMockEvents(taskId, events);

    const { result } = renderHook(() => useTaskStream(taskId), { wrapper });

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 150));
    });

    expect(result.current.status).toBe("completed");
    expect(result.current.progress).toBe(100);
    expect(result.current.pathId).toBe("path-term-999");
  });

  it("should support multiple subscribers and preserve shared registry connection", () => {
    const taskId = "shared-task-123";
    const sub1 = { onMessage: vi.fn(), onError: vi.fn() };
    const sub2 = { onMessage: vi.fn(), onError: vi.fn() };

    const unsub1 = subscribeToTask(taskId, sub1);
    const unsub2 = subscribeToTask(taskId, sub2);

    expect(sub1.onMessage).not.toHaveBeenCalled();

    const mockEvent: TaskEventDto = {
      event_id: "evt-123",
      task_id: taskId,
      type: "progress",
      status: "running",
      progress: 40,
      stage: "阶段一",
      message: "正在运行",
      result: null,
      timestamp: new Date().toISOString(),
    };

    MockTaskStreamTransport.triggerEvent(taskId, mockEvent);

    expect(sub1.onMessage).toHaveBeenCalledWith(mockEvent);
    expect(sub2.onMessage).toHaveBeenCalledWith(mockEvent);

    unsub1();
    // Connection remains because sub2 is still subscribed
    unsub2();
  });

  it("should support idempotent dispose registry calls", () => {
    expect(() => disposeTaskConnectionRegistry()).not.toThrow();
    expect(() => disposeTaskConnectionRegistry()).not.toThrow();
  });
});
